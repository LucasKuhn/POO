import java.util.Arrays;

public class ChecagemDeJogada
{
    private Dado[] dados ;
    private int[] array ;
    
    public ChecagemDeJogada(Copo copo)
    {
        this.dados = copo.getDados();
        this.array = new int[this.dados.length] ;
        for (int i = 0; i < this.dados.length; i++) 
        {
            this.array[i] = this.dados[i].valor ;
        }
        Arrays.sort(this.array) ;
    }
    
    public int validaSequencia()
    {
        for (int i = 0; i < this.array.length - 1; i++) 
        {
            if (array[i] != array[i+1] - 1) {
                return 0;
            } 
        }
        return 20 ;
    }
    
    public int validaFullHand()
    {
        int total = 0 ;
        for (int i = 0; i < 2; i++) 
        {
            if (array[i] != array[i+1]) {
                return 0;
            } 
            total += array[i] * 3;
        }
        for (int i = 3; i < 5; i++) 
        {
            if (array[3] != array[4]) {
                return 0;
            } 
            total += array[i] * 2;
        }
        return total + 30;
    }
    
    public int validaQuadra()
    {
        int total = 0 ;
        for (int i = 0; i < 3; i++) 
        {
            if (array[i] != array[i+1]) {
                return 0;
            }
            total += array[i] * 4;
        }
        return total + 40;
    }
    
    public int validaGeneral()
    {
        int total = 0 ;
        for (int i = 0; i < this.array.length; i++) 
        {
            if (i < 4 && array[i] != array[i+1]) {
                return 0;
            }
            total += array[i] * 5;
        }
        return total + 50;
    }
}
